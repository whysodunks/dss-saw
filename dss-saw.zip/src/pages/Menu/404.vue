<template>
	<div class="w-100">
		<div class="container px-4 text-center position-relative" style="top: 50px">
    	<h2 class="mb-4 pb-2 pt-3 font-medium color-black">Dalam <br>Pengembangan</h2>
	    <img src="../../assets/icon/under_construction.svg" width="250">
    	<p class="my-4 font-regular text-14 color-black">Maaf, Halaman ini sedang dalam pengembangan </p>
    	<router-link to="/">
    		<button type="button" class="button-primary px-4">Kembali ke Beranda</button>
    	</router-link>
    </div>
	</div>
</template>